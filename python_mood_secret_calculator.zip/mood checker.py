mood="relaxed"


if mood == "happy":
    print("It is great to see you happy!")
elif mood == "nervous":
    print("Take a deep breath 3 times")
elif mood == "sad":
    print("Talk to a good friend")
elif mood == "excited":
    print("Oh, that's cool!")
elif mood == "relaxed":
    print("Perfect, I'm relaxed too!")
else:
    print("I don't recognize this mood")